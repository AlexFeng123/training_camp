#ifndef COROUTINE_ENVIRONMENT_H
#define COROUTINE_ENVIRONMENT_H

#include "coroutine.h"

#include <stddef.h>
#include <string.h>
#include <memory.h>

struct  co_routine;
typedef struct co_env {
    // Coroutine calling stack
     struct co_routine *co_stack[1024];
    // Top of the coroutine calling stack
    size_t co_stack_top;
    // Main coroutine(root)
    struct co_routine *co_main;
}co_env_t;

void env_init(co_env_t *env);

static inline co_routine_t* env_current(co_env_t *env)
{
    return env->co_stack[env->co_stack_top - 1];
}

static inline void env_push(co_env_t *env,struct co_routine* co_routine)
{
    env->co_stack[env->co_stack_top++] = co_routine;
}

// Get current coroutine in the stack
static inline void env_pop(co_env_t *env) 
{
    env->co_stack_top--;
}


#endif //COROUTINE_ENVIRONMENT_H
