gcc *.c *.S -o test -O3 -g
