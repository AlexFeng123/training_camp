#ifndef COROUTINE_COROUTINE_H
#define COROUTINE_COROUTINE_H

#include "status.h"
#include "context.h"
#include <memory.h>

struct co_env;
typedef void (*routine_t)(void*);
typedef struct co_routine{
    size_t stats;
    co_context_t *context;
    routine_t entry;
    void *arg;
    struct co_env *env;
}co_routine_t;

co_routine_t*  co_create(struct co_env *env,routine_t routine,void *arg);
void    co_resume( co_routine_t *co_routine );
void    co_yield( co_routine_t *co_routine );
void    co_call_entry(co_routine_t *coroutine);
int     is_exit(co_routine_t *co_routine);
int     is_running(co_routine_t *co_routine);

#endif //COROUTINE_COROUTINE_H
