#ifndef COROUTINE_STATUS_H
#define COROUTINE_STATUS_H

#define MAIN      1 << 0
#define IDLE      1 << 1
#define RUNNING   1 << 2
#define EXIT      1 << 3

#endif //CORUTINE_STATUS_H
