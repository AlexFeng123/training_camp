#include "environment.h"

void env_init(co_env_t *env)
{
    co_routine_t* self;
    env->co_stack_top = 0;
    env->co_main = NULL;
    // save init（thread） context
    self = co_create(env,NULL,NULL);
    env_push(env,self);
}


