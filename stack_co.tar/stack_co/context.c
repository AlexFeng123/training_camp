#include "context.h"

extern void switch_context(co_context_t *, co_context_t *) asm("switch_context");

void ctx_switch(co_context_t *previous,co_context_t *current) 
{
    switch_context(previous, current);
}

static co_reg_t ctx_get_stack_pointer(co_context_t *co_context) 
{
    //stack from high address to low ,so co_stack + STACK_SIZE - 8 is SP 
    co_reg_t sp = co_context->co_stack + STACK_SIZE - sizeof(co_reg_t);
    sp = (co_reg_t)((unsigned long)sp & -16LL);//对齐
    return sp;
}

static void ctx_fill_registers(co_context_t *       co_context,void* sp, void* ret, void* rdi) 
{
    void** pRet = (void**) sp;
    memset(co_context->registers, 0, sizeof(co_context->registers));
    *pRet = (void*)ret;

    //第一次设置好，函数入口信息，类似call指令
    co_context->registers[RSP] = sp;//栈指针
    co_context->registers[RET] = (char*)ret;//入口函数地址
    co_context->registers[RDI] = rdi;//第一个入参
}

void ctx_prepare(co_context_t *       co_context,co_callback_t ret, void* rdi) 
{
    co_reg_t sp = ctx_get_stack_pointer(co_context);
    
    ctx_fill_registers(co_context,sp, ret, rdi);
}

int ctx_test(co_context_t *co_context) 
{
    char current;
    int diff = &current - co_context->co_stack;
    return diff >= 0 && diff < STACK_SIZE;
}


