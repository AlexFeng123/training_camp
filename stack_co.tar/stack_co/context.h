#ifndef COROUTINE_CONTEXT_H
#define COROUTINE_CONTEXT_H

#include <stddef.h>
#include <string.h>

#define STACK_SIZE  (8 * 1024)



#define  RDI 7
#define  RSI 8
#define  RET 9
#define  RSP 13

typedef char* co_reg_t;
/**
 * The context of coroutine(in x86-64)
 *
 * low | _registers[0]: r15  |
 *     | _registers[1]: r14  |
 *     | _registers[2]: r13  |
 *     | _registers[3]: r12  |
 *     | _registers[4]: r9   |
 *     | _registers[5]: r8   |
 *     | _registers[6]: rbp  |
 *     | _registers[7]: rdi  |
 *     | _registers[8]: rsi  |
 *     | _registers[9]: ret  |//ret func addr
 *     | _registers[10]: rdx |
 *     | _registers[11]: rcx |
 *     | _registers[12]: rbx |
 * hig | _registers[13]: rsp |
 *
 */
typedef struct co_context{
#if defined(__x86_64__)
    co_reg_t registers[14];
#else
#error "no support "
#endif
    char co_stack[STACK_SIZE];
}co_context_t;

typedef void* (*co_callback_t)(void *) ;

int ctx_test(co_context_t *co_context);
void ctx_prepare(co_context_t *co_context,co_callback_t ret, void* rdi);
void ctx_switch(co_context_t *previous,co_context_t *current);

#endif //COROUTINE_CONTEXT_H
