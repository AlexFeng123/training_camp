#include "coroutine.h"
#include "environment.h"
#include <stdio.h>

int is_exit(co_routine_t* co_routine) 
{
    return co_routine->stats & EXIT;
}

int is_running(co_routine_t* co_routine) 
{
    return co_routine->stats & RUNNING;
}

void co_resume(co_routine_t* co_routine) 
{
    co_routine_t* previous = env_current(co_routine->env);

    //第一次运行，需要先进入协程入口函数
    if (!(co_routine->stats & RUNNING)) {
        ctx_prepare(co_routine->context,(co_callback_t)co_call_entry, co_routine);
        co_routine->stats |= RUNNING;
    }
    //启动协程，切换到协程上下文运行
    env_push(co_routine->env, co_routine);
    ctx_switch(previous->context,co_routine->context);
}

void co_yield(co_routine_t *co_routine) 
{
    co_routine_t *previous_routine;
        
    env_pop(co_routine->env);
    previous_routine = env_current(co_routine->env);
    ctx_switch(co_routine->context,previous_routine->context);
}

//协程入口函数
void co_call_entry(co_routine_t *co_routine) 
{ 
    routine_t routine = co_routine->entry;
    
    //调用协程绑定的函数
    if (routine) routine(co_routine->arg);
    
    co_routine->stats ^= (EXIT | RUNNING);

    //协程结束后，返回之前调用co_resume地方
    co_yield(co_routine);
}

co_routine_t* co_create(struct co_env *env,routine_t routine,void *arg) {
    co_routine_t *co_routine = (co_routine_t*)malloc(sizeof(co_routine_t));
   
    memset(co_routine,0,sizeof(co_routine_t)); 
    
    co_routine->context = (co_context_t*)malloc(sizeof(co_context_t));
    memset(co_routine->context,0,sizeof(co_context_t)); 

    co_routine->entry = routine;
    co_routine->arg = arg;
    co_routine->env = env;

    return co_routine;
}

