#include "coroutine.h"
#include "environment.h"

#include <stdio.h>

co_env_t env;
void where(co_routine_t *co_routine) 
{   
    printf("running code in a %s\n",ctx_test(co_routine->context) ? "coroutine" : "thread");
}

void print1(void * arg)
{    
    co_routine_t *co_routine= env_current(&env);
    printf("print1-1\n");
    co_yield(co_routine);
    printf("print1-2\n");
}

void print2(void * arg) {
    co_routine_t *co_routine= env_current(&env);
    co_routine_t *co_routine1= (co_routine_t*)arg;
    printf("print2-3\n");
    co_resume(co_routine1);
    where(co_routine);
    printf("print2-bye\n");
}

int main() 
{
    env_init(&env);
    co_routine_t *co1 = co_create(&env,print1,NULL);
    co_routine_t *co2 = co_create(&env,print2,co1); 
    co_resume(co1);
    co_resume(co2);
    where(co1);
    return 0;
}
